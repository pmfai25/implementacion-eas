/**
 * @file normalizabd.cpp Fichero para normalizar los ficheros de la base de datos
 * @author Manuel Marcelino Titos Luzón
*/

#include<iostream>
#include<vector>
#include<fstream>
#include<cstring>
using namespace std;

/**
 * @brief Calcula el mínimo y el máximo de una matriz
 * @param datos Datos para normalizar 
 * @param columna Columna de la matriz de datos
 * @param minimo Dato donde se va a guardar el mínimo de la columna
 * @param maximo Dato donde se va a guardar el máximo de la columna
 * 
 * Calcula el mínimo y el máximo de la matriz devolviéndolos en minimo y en maximo
*/
void calcularMinimoMaximo(const vector<vector<double> > &datos, int columna, double &minimo, double &maximo)
{
	maximo = minimo = datos[0][columna];
	
	for(unsigned int i = 0; i < datos.size(); i++)
	{
		if( datos[i][columna] > maximo )
			maximo = datos[i][columna];
		if( datos[i][columna] < minimo )
			minimo = datos[i][columna];
	}
}

/**
 * @brief Normaliza una columna
 * @param entrenamiento Datos de entrenamiento
 * @param test Datos de test
 * @param columna Columna a normalizar
 * @param minimo Minimo de la columa
 * @param maximo Maximo de la columna
 * 
 * Normaliza una columna de los datos de entrenamiento y test 
*/
void normalizaColumna(vector<vector<double> > &entrenamiento, vector<vector<double> > &test, int columna, double minimo, double maximo)
{
	for(unsigned int i = 0; i < entrenamiento.size(); i++)
		entrenamiento[i][columna] = (entrenamiento[i][columna]-minimo)/(maximo-minimo);
	
	for(unsigned int i = 0; i < test.size(); i++)
		test[i][columna] = (test[i][columna]-minimo)/(maximo-minimo);
}

/**
 * @brief Carga los datos de un fichero
 * @param fichero Fichero donde se encuentran los datos
 * @param matrizdatos Matriz donde se van a guardar los datos
 * @param clasesfilas Vector donde se guardarán las clases de los atributos
 * 
 * Carga los datos y las clases desde un fichero
*/
void cargarDatosFichero(const char * fichero, vector<vector<double> > &matrizdatos, vector<string> &clasesfilas)
{
	ifstream ficherosinnormalizar(fichero);
		
	if( ficherosinnormalizar )
	{
		int numeroatributos, numeroclases = 2, totalfilas;
		double datoleido;
		vector<string> clases;
		vector<double> fila;
		string basura, clase, ficheronormalizado;
			
		if( strcmp(fichero, "bd/no_normalizada/ozone.tra") == 0 )
		{
			numeroatributos = 73;
			totalfilas = 148;
			ficheronormalizado = "bd/normalizada/ozone.tra";
		}
		else
			if( strcmp(fichero, "bd/no_normalizada/ozone.tst") == 0 )
			{
				numeroatributos = 73;
				totalfilas = 37;
				ficheronormalizado = "bd/normalizada/ozone.tst";
			} 
			else
				if( strcmp(fichero, "bd/no_normalizada/sonar.tra") == 0 )
				{
					numeroatributos = 61;
					totalfilas = 165;
					ficheronormalizado = "bd/normalizada/sonar.tra";
				}
				else
					if( strcmp(fichero, "bd/no_normalizada/sonar.tst") == 0 )
					{
						numeroatributos = 61;
						totalfilas = 41;
						ficheronormalizado = "bd/normalizada/sonar.tst";
					}
					else
						if( strcmp(fichero, "bd/no_normalizada/spambase.tra") == 0 )
						{
							numeroatributos = 58;
							totalfilas = 368;
							ficheronormalizado = "bd/normalizada/spambase.tra";
						}
						else
							if( strcmp(fichero, "bd/no_normalizada/spambase.tst") == 0 )
							{
								numeroatributos = 58;
								totalfilas = 91;
								ficheronormalizado = "bd/normalizada/spambase.tst";
							}
		
		// ***** Leo la relación *****
		ficherosinnormalizar >> basura;
		ficherosinnormalizar >> basura;
		// ***************************
		// ***** Leo los atributos *****
		for(int i = 0; i < numeroatributos-1; i++) // Leo hasta atributos-1 para leer las clases a parte
		{
			ficherosinnormalizar >> basura; // leo @atribute
			ficherosinnormalizar >> basura; // leo el nombre del atributo
			ficherosinnormalizar >> basura; // leo el tipo del atributo
		}
		// *****************************
		// ***** Leo las clases *****
		ficherosinnormalizar >> basura; // Leo @atribute
		ficherosinnormalizar >> basura; // Leo Class o lo que sea
		for(int i = 0; i < numeroclases; i++)
		{
			ficherosinnormalizar >> clase; // Leo @atribute
			clases.push_back(clase);
		}
		// **************************
		
		// ***** Leo los datos *****
		ficherosinnormalizar >> basura; // Leo @data
		for(int filasleidas = 0; filasleidas < totalfilas; filasleidas++)
		{
			for(int j = 0; j < numeroatributos; j++)
			{
				if( j < numeroatributos-1 ) // Leo un dato
				{
					ficherosinnormalizar >> datoleido; // Leo el dato
					ficherosinnormalizar >> basura; // Leo la coma
					fila.push_back(datoleido);
				}
				else // Leo una clase
				{
					ficherosinnormalizar >> clase;
					clasesfilas.push_back(clase);
				}
			}
			matrizdatos.push_back(fila);
			fila.clear();
		}
	}
	else
		cerr << "\tError abriendo el fichero " << fichero << endl;
	ficherosinnormalizar.close();
}

int main(int args, char* argv[])
{
	if( args < 2 )
	{
		cerr << "\tError. Introduzca la ruta del fichero de la base de datos para normalizarlo: ozone, sonar o spambase" << endl;
		cerr << "\t\tbin/normalizabd ozone" << endl;
		cerr << "\t\tbin/normalizabd sonar" << endl;
		cerr << "\t\tbin/normalizabd spambase" << endl;
	}
	else
	{
		vector<string> clasesentrenamiento, clasestest;
		vector<vector<double> > datosentrenamiento, datostest;
		string ficheronormalizadoentrenamiento, ficheronormalizadotest;
		
		if(strcmp(argv[1],"ozone") == 0)
		{
			cargarDatosFichero("bd/no_normalizada/ozone.tra", datosentrenamiento, clasesentrenamiento);
			cargarDatosFichero("bd/no_normalizada/ozone.tst", datostest, clasestest);
			ficheronormalizadoentrenamiento = "bd/normalizada/ozone.tra";
			ficheronormalizadotest = "bd/normalizada/ozone.tst";
		}
		if(strcmp(argv[1],"sonar") == 0 )
		{
			cargarDatosFichero("bd/no_normalizada/sonar.tra", datosentrenamiento, clasesentrenamiento);
			cargarDatosFichero("bd/no_normalizada/sonar.tst", datostest, clasestest);
			ficheronormalizadoentrenamiento = "bd/normalizada/sonar.tra";
			ficheronormalizadotest = "bd/normalizada/sonar.tst";
		}
		if(strcmp(argv[1],"spambase") == 0)
		{
			cargarDatosFichero("bd/no_normalizada/spambase.tra", datosentrenamiento, clasesentrenamiento);
			cargarDatosFichero("bd/no_normalizada/spambase.tst", datostest, clasestest);
			ficheronormalizadoentrenamiento = "bd/normalizada/spambase.tra";
			ficheronormalizadotest = "bd/normalizada/spambase.tst";
		}
		
		// Ya tengo leídos todos los atributos de los ficheros, las clases y los datos
		// Procedo a normalizar los datos
		for(unsigned int i = 0; i < datosentrenamiento[0].size() && i < datostest[0].size(); i++)
		{
			double minimo, maximo, minimoentrenamiento, maximoentrenamiento, minimotest, maximotest;
			calcularMinimoMaximo(datosentrenamiento, i, minimoentrenamiento, maximoentrenamiento);
			//cout << minimoentrenamiento << ", " << maximoentrenamiento << endl;
			calcularMinimoMaximo(datostest, i, minimotest, maximotest);
			//cout << minimotest << ", " << maximotest << endl;
			
			if( minimoentrenamiento <= minimotest )
				minimo = minimoentrenamiento;
			else
				minimo = minimotest;
			
			if( maximoentrenamiento >= maximotest )
				maximo = maximoentrenamiento;
			else
				maximo = maximotest;
			
			normalizaColumna(datosentrenamiento, datostest, i, minimo, maximo);
		}
		
		ofstream ficherosalida(ficheronormalizadoentrenamiento.c_str());
		if( ficherosalida )
		{
			for(unsigned int i = 0; i < datosentrenamiento.size(); i++)
			{
				for(unsigned int j = 0; j < datosentrenamiento[0].size(); j++)
					ficherosalida << datosentrenamiento[i][j] << ", "; // Escribo el dato ya normalizado
				ficherosalida << clasesentrenamiento[i]; // Escribo la clase
				ficherosalida << endl;
			}
		}
		else
			cerr << "Error creando el fichero " << ficheronormalizadoentrenamiento << endl;
		ficherosalida.close();
		
		ofstream ficherosalida2(ficheronormalizadotest.c_str());
		if( ficherosalida2 )
		{
			for(unsigned int i = 0; i < datostest.size(); i++)
			{
				for(unsigned int j = 0; j < datostest[0].size(); j++)
					ficherosalida2 << datostest[i][j] << ", "; // Escribo el dato ya normalizado
				ficherosalida2 << clasestest[i]; // Escribo la clase
				ficherosalida2 << endl;
			}
		}
		else
			cerr << "Error creando el fichero " << ficheronormalizadotest << endl;
		ficherosalida2.close();
		// ******************************************************
	}
}
